# Wildscape

A location-based field guide using iNaturalist and Open-Meteo.

Run `node server.cjs` and open http://127.0.0.1:4173. Node 20+ is recommended. No packages, API keys or build step required. Alternatively, open the delivered Wildscape.html directly in a modern browser. Internet is needed for live data and photos.

Data scope: a 10/25/50 km circle around a town center, verifiable wild observations, all dates. Native/introduced filters depend on iNaturalist local classifications. Invasive references cover selected species in the US, UK, Australia and South Africa and additional Texas species; other invasive status is unassessed. Venom flags cover Viperidae, Elapidae, Latrodectus, Loxosceles and Scorpiones; they are not exhaustive and do not establish safety.

The bundled Austin snapshot was retrieved September 23, 2026. Individual photo licenses and attribution appear in species details.

Verified: live Austin and Cambridge search, category/origin/name filtering, venomous species detail, empty state, desktop/mobile layouts, valid and invalid WebMCP filters, JavaScript syntax. Hosting was not completed because the Sites hosting scripts disappeared from the installed plugin directory during work.
